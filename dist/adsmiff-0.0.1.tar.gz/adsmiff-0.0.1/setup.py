from setuptools import setup, find_packages

setup(
    name='adsmiff',
    version='0.0.1',
    packages=find_packages(),
    author='Jai Madera',
    author_email='onesthathumbled@gmail.com',
    description='adsmiff is a Python library tailored for business mathematics.',
    install_requires = [
        # Add dependencies here.
        # e.g. 'numpy>=1.11.1'
    ],
)